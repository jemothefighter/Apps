
import { fetchAggregatedFeeds } from '../../lib/feeds';
export default async function handler(req, res) {
try {
const feeds = await fetchAggregatedFeeds();
res.json({ ok: true, feeds });
} catch (err) {
console.error(err);
res.status(500).json({ ok: false, error: err.message });
}
}
